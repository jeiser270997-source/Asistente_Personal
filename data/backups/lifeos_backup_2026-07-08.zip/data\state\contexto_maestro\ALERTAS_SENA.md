# Alertas SENA - BASES DE DATOS GENERALIDADES Y SISTEMAS DE GESTION (3549155)
> Extraido: 7/7/2026, 8:56:21 a. m.
> **FECHA LIMITE GLOBAL: 27/07/2026**

## Cronograma con Fechas

### Actividad 1
- 🔴 **Foro Temático. Reconocer las características de la evolución de las bases de datos en cada una de sus etapas** → 22/06/2026 al 30/06/2026 (-7 dias)

### Actividad 2
- 🔴 **Cuadro comparativo. Comprender los conceptos de bases de datos conceptuales** → 01/07/2026 al 07/07/2026 (0 dias)

### Actividad 3
- 🟢 **Actividad interactiva. Identificar los conceptos de normalización en las bases de datos** → 08/07/2026 al 20/07/2026 (13 dias)

### Actividad 4
- 🟢 **Actividad interactiva. Reconocer los conceptos generales de una base de datos relacional** → 21/07/2026 al 27/07/2026 (20 dias)

## Evidencias del curso

### ACTIVIDADES INICIALES
- [ ] **CUESTIONARIO**: Sondeo de conocimientos previos Prueba de Conocimiento

### ACTIVIDAD 1
- [x] **TAREA**: Taller: Aplicar los conceptos de una base de datos según requerimientos de una empresa. Evidencia ✅

### Evidencias
- [x] **TAREA**: Taller: Aplicar los conceptos de una base de datos según requerimientos de una empresa. Evidencia ✅

### ACTIVIDAD 2
- [x] **TAREA**: Evidencia: Cuadro comparativo. Comprender los conceptos de bases de datos conceptuales ✅
- [x] **TAREA**: Evidencia: Taller aplicado. Desarrollar los componentes de las bases de datos conceptuales ✅

### Evidencias
- [ ] **TAREA**: Evidencia: Cuadro comparativo. Comprender los conceptos de bases de datos conceptuales
- [x] **TAREA**: Evidencia: Taller aplicado. Desarrollar los componentes de las bases de datos conceptuales ✅

### ACTIVIDAD 3
- [ ] **SCORM**: SCORM Evidencia: Actividad interactiva. Identificar los conceptos de normalización en las bases de datos Paquete SCORM
- [ ] **TAREA**: Evidencia documento: Aplicar la técnica de normalización a una base de datos en una empresa.

### Evidencias
- [ ] **SCORM**: SCORM Evidencia: Actividad interactiva. Identificar los conceptos de normalización en las bases de datos Paquete SCORM
- [ ] **TAREA**: Evidencia documento: Aplicar la técnica de normalización a una base de datos en una empresa.

### ACTIVIDAD 4
- [ ] **SCORM**: SCORM Evidencia: Actividad interactiva. Reconocer los conceptos generales de una base de datos relacional. Paquete SCORM
- [ ] **TAREA**: Evidencia: Estudio de caso. Diseñar una base de datos relacional para una empresa
- [ ] **CUESTIONARIO**: Sondeo de evaluacion del programa Prueba de Conocimiento

### Evidencias
- [ ] **SCORM**: SCORM Evidencia: Actividad interactiva. Reconocer los conceptos generales de una base de datos relacional. Paquete SCORM
- [ ] **TAREA**: Evidencia: Estudio de caso. Diseñar una base de datos relacional para una empresa
- [ ] **CUESTIONARIO**: Sondeo de evaluacion del programa Prueba de Conocimiento

## Vencimientos proximos

- 🟢 Evidencia: Cuadro comparativo. Comprender los conceptos de bases de datos conceptuales ✅ Entregado
- 🟢 Evidencia: Taller aplicado. Desarrollar los componentes de las bases de datos conceptuales ✅ Entregado
- 🟢 Foro Temático → 30 de junio de 2026 (entregado)
- 🟢 Taller: Aplicar los conceptos... → 30 de junio de 2026 (entregado)
- 🟢 Evidencia: Cuadro comparativo → 22 de junio de 2026 (entregado)
- 🟢 Evidencia: Taller aplicado → 22 de junio de 2026 (entregado)
- 🟢 SCORM Actividad interactiva (normalización) → 22 de junio de 2026 ✅ Entregado
